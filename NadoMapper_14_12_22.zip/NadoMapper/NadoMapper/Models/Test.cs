﻿namespace NadoMapper.Models
{
  public record Test : ModelBase
  {
    public string Name { get; set; }
  }
}